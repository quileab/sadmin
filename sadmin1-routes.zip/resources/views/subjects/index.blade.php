<div>
 {{-- No se utiliza en un Fullpage livewire component --}}
</div>
