<svg  {!! $attributes->merge(['class' => 'h-6 w-6']) !!}
 fill="none" version="1.1" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
 <rect x="1.1285" y="7.4219" width="21.658" height="9.375" ry="4.6875" fill-opacity="0" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.109"/>
 <path d="m21.417 12.119a3.3184 3.3113 0 0 1-3.3159 3.3113 3.3184 3.3113 0 0 1-3.3209-3.3064 3.3184 3.3113 0 0 1 3.311-3.3162 3.3184 3.3113 0 0 1 3.3258 3.3014" fill="currentColor" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.109"/>
</svg>
