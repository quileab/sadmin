<?php

return [

    'Email' => 'Email',
    'Password' => 'Contraseña',
    'Remember me' => 'Recuérdame',
    'Forgot your password?' => '¿Olvidaste tu contraseña?',
    'Manage Account' => 'Administrar Cuenta',
    'Profile' => 'Perfil',
    'Login' => 'Iniciar Sesión',
    'Logout' => 'Cerrar Sesión',
    'Whoops! Something went wrong.' => 'Ups! Algo falló.',
];
