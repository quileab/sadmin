<?php

return [

    'Email' => 'Email',
    'Password' => 'Password',
    'Remember me' => 'Remember me.',
    'Forgot your password?' => 'Forgot your password?',
    'Manage Account' => 'Manage Account',
    'Profile' => 'Profile',
    'Login' => 'Login',
    'Logout' => 'Logout',
    'Whoops! Something went wrong.' => 'Whoops! Something went wrong.',
];
